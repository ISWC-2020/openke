package Experiment_data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Statement;
import org.apache.jena.rdf.model.StmtIterator;

public class Character_data {

	public static void main(String[] args) throws IOException {

		HashSet<Integer> rs = new HashSet<>();
		HashSet<Integer> rp = new HashSet<>();
		HashSet<Integer> ro = new HashSet<>();
		HashSet<Statement> rhs = new HashSet<>();
		StringBuilder stringBuilder = new StringBuilder();
		FileInputStream fis = new FileInputStream("DBpedia_Data/DBpedia.nt");
		InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
		Model model = ModelFactory.createDefaultModel();
		model.read(isr, "", "TTL");

		HashSet<Integer> s = new HashSet<>();
		HashSet<Integer> p = new HashSet<>();
		HashSet<Integer> o = new HashSet<>();
		HashSet<Statement> sta = new HashSet<>();
		StmtIterator iter = model.listStatements();
		while (iter.hasNext()) {
			Statement stmt = iter.nextStatement(); // get next statement

			sta.add(stmt);
//			int subject = stmt.getSubject().hashCode();
//			int predicate = stmt.getPredicate().hashCode();
//			int object = stmt.getObject().hashCode();
//			
//			s.add(subject);
//			p.add(predicate);
//			o.add(object);		
		}

		System.out.println("DBpedia_triples : " + sta.size() + " DBpedia_subject : " + s.size() + " DBpedia_predicate: "
				+ p.size() + " DBpedia_object: " + o.size());

		for (Statement st : sta) {

			stringBuilder.append(st.getSubject().hashCode() + ";" + st.getPredicate().hashCode() + ";"
					+ st.getObject().hashCode() + "\r\n");
		}

//		File writename = new File("C:\\Users\\user\\Desktop\\DBpedia.txt"); // 相对路径，如果没有则要建立一个新的output。txt文件
//		writename.createNewFile(); // 创建新文件
//		BufferedWriter out = new BufferedWriter(new FileWriter(writename));
//		out.write(stringBuilder.toString()); // \r\n即为换行
//		
//		out.flush(); // 把缓存区内容压入文件
//		out.close(); // 最后记得关闭文件

		FileInputStream fi = new FileInputStream("DBpedia_Data/DrugBank.nt");
		InputStreamReader is = new InputStreamReader(fi, "UTF-8");
		Model mod = ModelFactory.createDefaultModel();
		mod.read(is, "", "TTL");
		StringBuilder Builder = new StringBuilder();
		HashSet<Integer> hs = new HashSet<>();
		HashSet<Integer> hp = new HashSet<>();
		HashSet<Integer> ho = new HashSet<>();
		HashSet<Statement> stt = new HashSet<>();
		StmtIterator ite = mod.listStatements();
		while (ite.hasNext()) {
			Statement stm = ite.nextStatement(); // get next statement

			stt.add(stm);
//			int subjec = stm.getSubject().hashCode();
//			int predicat = stm.getPredicate().hashCode();
//			int objec = stm.getObject().hashCode();
//			
//			hs.add(subjec);
//			hp.add(predicat);
//			ho.add(objec);		
		}
		System.out.println("DrugBank_subject : " + stt.size() + " DrugBank_subject : " + hs.size()
				+ " DrugBank_predicate: " + hp.size() + " DrugBank_object: " + ho.size());

		for (Statement st : stt) {
			Builder.append(st.getSubject().hashCode() + ";" + st.getPredicate().hashCode() + ";"
					+ st.getObject().hashCode() + "\r\n");
		}

//			
//			File name = new File("C:\\Users\\user\\Desktop\\DrugBank.txt"); // 相对路径，如果没有则要建立一个新的output。txt文件
//			name.createNewFile(); // 创建新文件
//			BufferedWriter ou = new BufferedWriter(new FileWriter(name));
//			ou.write(Builder.toString()); // \r\n即为换行
//			
//			ou.flush(); // 把缓存区内容压入文件
//			ou.close(); // 最后记得关闭文件
//		

		FileInputStream f = new FileInputStream("DBpedia_Data/LinkedGeoData.nt");
		InputStreamReader i = new InputStreamReader(f, "UTF-8");
		Model mo = ModelFactory.createDefaultModel();
		mo.read(i, "", "TTL");
		StringBuilder Bui = new StringBuilder();
		HashSet<Integer> hss = new HashSet<>();
		HashSet<Integer> hpp = new HashSet<>();
		HashSet<Integer> hoo = new HashSet<>();
		HashSet<Statement> ss = new HashSet<>();
		StmtIterator it = mo.listStatements();
		while (it.hasNext()) {
			Statement st = it.nextStatement(); // get next statement

			ss.add(st);
//			int subje = st.getSubject().hashCode();
//			int predica = st.getPredicate().hashCode();
//			int obje = st.getObject().hashCode();

//			hss.add(subje);
//			hpp.add(predica);
//			hoo.add(obje);		
		}
		System.out.println("LinkedGeoData_triples : " + ss.size() + " LinkedGeoData_subject : " + stt.size()
				+ "LinkedGeoData_subject : " + hs.size() + " LinkedGeoData_predicate: " + hp.size()
				+ " DrugBank_object: " + ho.size());

		for (Statement st : ss) {
			Bui.append(st.getSubject().hashCode() + ";" + st.getPredicate().hashCode() + ";" + st.getObject().hashCode()
					+ "\r\n");
		}

//			
//			File na = new File("C:\\Users\\user\\Desktop\\LinkedGeoData.txt"); // 相对路径，如果没有则要建立一个新的output。txt文件
//			na.createNewFile(); // 创建新文件
//			BufferedWriter ow = new BufferedWriter(new FileWriter(na));
//			ow.write(Bui.toString()); // \r\n即为换行
//			
//			ow.flush(); // 把缓存区内容压入文件
//			ow.close(); // 最后记得关闭文件
//		

		rs.clear();
		rs.addAll(s);
		rs.addAll(hs);
		rs.addAll(hss);
		// -------------------------------
		rp.clear();
		rp.addAll(p);
		rp.addAll(hp);
		rp.addAll(hpp);
		// --------------------------------
		ro.clear();
		ro.addAll(o);
		ro.addAll(ho);
		ro.addAll(hoo);
		// --------------------------------
		rhs.clear();
		rhs.addAll(sta);
		rhs.addAll(stt);
		rhs.addAll(ss);
		System.out.println("mixed_triples : " + rhs.size() + " mixed_subject : " + rs.size() + " mixed_subject: "
				+ rp.size() + " mixed_subject: " + ro.size());
		File fna = new File("C:\\Users\\user\\Desktop\\MixedData.txt"); // 相对路径，如果没有则要建立一个新的output。txt文件
		// fna.createNewFile(); // 创建新文件
		BufferedWriter oww = new BufferedWriter(new FileWriter(fna));

		StringBuilder Bi = new StringBuilder();
		int jishu = 0;
		for (Statement st : rhs) {
			jishu++;
			Bi.append(st.getSubject().hashCode() + ";" + st.getPredicate().hashCode() + ";" + st.getObject().hashCode()
					+ "\r\n");
			if (jishu == 344421) {

				oww.write(Bi.toString()); // \r\n即为换行

				Bi.setLength(0);
				jishu = 0;
			}

		}
		oww.flush(); // 把缓存区内容压入文件
		oww.close(); // 最后记得关闭文件

//		File fna = new File("C:\\Users\\user\\Desktop\\MixedData.txt"); // 相对路径，如果没有则要建立一个新的output。txt文件
//		//fna.createNewFile(); // 创建新文件
//		BufferedWriter oww = new BufferedWriter(new FileWriter(fna));
//		oww.write(Bi.toString()); // \r\n即为换行
//		
//		oww.flush(); // 把缓存区内容压入文件
//		oww.close(); // 最后记得关闭文件
//	

	}
}
