package ELKIBuilder;

import de.lmu.ifi.dbs.elki.logging.Logging;
import de.lmu.ifi.dbs.elki.utilities.ClassGenericsUtil;
import de.lmu.ifi.dbs.elki.utilities.exceptions.AbortException;
import de.lmu.ifi.dbs.elki.utilities.optionhandling.OptionID;
import de.lmu.ifi.dbs.elki.utilities.optionhandling.parameterization.ListParameterization;

public final class ELKIBuilder<T> {
	private static final Logging LOG = Logging.getLogger(ELKIBuilder.class);
	private Class<? super T> clazz;
	private ListParameterization p = new ListParameterization();

	public ELKIBuilder(Class<? super T> clazz) {
		this.clazz = clazz;
	}

	public ELKIBuilder<T> with(OptionID opt, Object value) {
		p.addParameter(opt, value);
		return this;
	}

	public ELKIBuilder<T> with(OptionID opt) {
		p.addFlag(opt);
		return this;
	}

	

	@SuppressWarnings("unchecked")
	public <C extends T> C build() {
		if (p == null) {
			throw new AbortException("build() may be called only once.");
		}
		final T obj = ClassGenericsUtil.parameterizeOrAbort(clazz, p);
		if (p.hasUnusedParameters()) {
			LOG.warning("Unused parameters: " + p.getRemainingParameters());
		}
		p = null; // Prevent build() from being called again.
		return (C) obj;
	}
}