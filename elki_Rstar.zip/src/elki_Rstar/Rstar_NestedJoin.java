package elki_Rstar;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import ELKIBuilder.ELKIBuilder;
import de.lmu.ifi.dbs.elki.data.DoubleVector;
import de.lmu.ifi.dbs.elki.data.NumberVector;
import de.lmu.ifi.dbs.elki.data.type.TypeUtil;
import de.lmu.ifi.dbs.elki.database.Database;
import de.lmu.ifi.dbs.elki.database.QueryUtil;
import de.lmu.ifi.dbs.elki.database.StaticArrayDatabase;
import de.lmu.ifi.dbs.elki.database.ids.DBIDRange;
import de.lmu.ifi.dbs.elki.database.ids.DoubleDBIDList;
import de.lmu.ifi.dbs.elki.database.ids.DoubleDBIDListIter;
import de.lmu.ifi.dbs.elki.database.query.knn.KNNQuery;
import de.lmu.ifi.dbs.elki.database.relation.Relation;
import de.lmu.ifi.dbs.elki.datasource.ArrayAdapterDatabaseConnection;
import de.lmu.ifi.dbs.elki.datasource.DatabaseConnection;
import de.lmu.ifi.dbs.elki.distance.distancefunction.geo.LatLngDistanceFunction;
import de.lmu.ifi.dbs.elki.index.tree.spatial.rstarvariants.rstar.RStarTreeFactory;
import de.lmu.ifi.dbs.elki.index.tree.spatial.rstarvariants.strategies.bulk.SortTileRecursiveBulkSplit;
import de.lmu.ifi.dbs.elki.logging.LoggingConfiguration;
import de.lmu.ifi.dbs.elki.math.geodesy.WGS84SpheroidEarthModel;
import de.lmu.ifi.dbs.elki.persistent.AbstractPageFileFactory;

public class Rstar_NestedJoin {

	public static void main(String[] args) throws IOException {
		// Set the logging level to statistics:
		LoggingConfiguration.setStatistics();
        int knn_size= 7;
		// Note: ELKI has a nice data generator class, use that instead.
		double[][] data = new double[272118][3];
		String[] real_data = new String[272118];
		int line = 0;
		// BufferedReader是可以按行读取文件
		FileInputStream inputStream = new FileInputStream("C:\\Users\\user\\Desktop\\Hash_Triple2HashValues_100.txt");
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

		String str = null;
		while ((str = bufferedReader.readLine()) != null) {
			real_data[line] = str;
			// System.out.println(str);
			data[line][0] = Double.valueOf(str.split(",")[0]);
			data[line][1] = Double.valueOf(str.split(",")[1]);
			data[line][2] = Double.valueOf(str.split(",")[2]);
			line++;
		}

		inputStream.close();
		bufferedReader.close();

		// Adapter to load data from an existing array.
		DatabaseConnection dbc = new ArrayAdapterDatabaseConnection(data);

		// Since the R-tree has so many options, it is a bit easier to configure it
		// using the parameterization API, which handles defaults, instantiation,
		// and additional constraint checks.
		RStarTreeFactory<?> indexfactory = new ELKIBuilder<>(RStarTreeFactory.class) //
				// If you have large query results, a larger page size can be better.
				.with(AbstractPageFileFactory.Parameterizer.PAGE_SIZE_ID, 800) //
				// Use bulk loading, for better performance.
				.with(RStarTreeFactory.Parameterizer.BULK_SPLIT_ID, SortTileRecursiveBulkSplit.class).build();
		
		// Create the database, and initialize it.
		Database db = new StaticArrayDatabase(dbc, Arrays.asList(indexfactory));
		// This will build the index of the database.
		db.initialize();
		// Relation containing the number vectors we put in above:
		Relation<NumberVector> rel = db.getRelation(TypeUtil.NUMBER_VECTOR_FIELD);
		// We can use this to identify rows of the input data below.
		DBIDRange ids = (DBIDRange) rel.getDBIDs();

		// We use the WGS84 earth model, and "latitude, longitude" coordinates:
		// This distance function returns meters.
		// latLngRadToECEF
		LatLngDistanceFunction df = new LatLngDistanceFunction(WGS84SpheroidEarthModel.STATIC);

		System.out.println("NESTED JOIN ALGORITHM");
		System.out.println("---------star-----" + System.currentTimeMillis());

		double[] t1 = new double[3];
		t1[0] = 2120941248;
		t1[1] = 201934756;
		double[] t2 = new double[3];
		t2[0] = -0.09427758;
		t2[1] = 6.881211;
		
		DoubleVector target1 = new DoubleVector(t1);
		DoubleVector target2 = new DoubleVector(t2);

		// k nearest neighbor query:
		KNNQuery<NumberVector> RangeQuery_one = QueryUtil.getKNNQuery(rel, df, t1);
		KNNQuery<NumberVector> RangeQuery_two = QueryUtil.getKNNQuery(rel, df, t2);

		DoubleDBIDList RangeQuery_One_Results = RangeQuery_one.getKNNForObject(target1, knn_size);
		DoubleDBIDList RangeQuery_Two_Results = RangeQuery_two.getKNNForObject(target2, knn_size);
		System.out.println(RangeQuery_One_Results.size());
		System.out.println(RangeQuery_Two_Results.size());
		// Iterate over all results.
		for (DoubleDBIDListIter itO = RangeQuery_One_Results.iter(); itO.valid(); itO.advance()) {
			//System.out.println(rel.get(itO));
			
			System.out.println("<location>: " + ids.getOffset(itO));
			System.out.println("<Value> : " + real_data[ids.getOffset(itO)]);
			
			for (DoubleDBIDListIter itT = RangeQuery_Two_Results.iter(); itT.valid(); itT.advance()) {
				if (rel.get(itO).getValue(2).equals(rel.get(itT).getValue(0))) {
				}
			}
		}
		System.out.println("---------end------" + System.currentTimeMillis());
	}

}
