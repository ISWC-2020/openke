package elki_Rstar;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import ELKIBuilder.ELKIBuilder;
import de.lmu.ifi.dbs.elki.data.DoubleVector;
import de.lmu.ifi.dbs.elki.data.NumberVector;
import de.lmu.ifi.dbs.elki.data.type.TypeUtil;
import de.lmu.ifi.dbs.elki.database.Database;
import de.lmu.ifi.dbs.elki.database.QueryUtil;
import de.lmu.ifi.dbs.elki.database.StaticArrayDatabase;
import de.lmu.ifi.dbs.elki.database.ids.DBIDRange;
import de.lmu.ifi.dbs.elki.database.ids.DoubleDBIDList;
import de.lmu.ifi.dbs.elki.database.ids.DoubleDBIDListIter;
import de.lmu.ifi.dbs.elki.database.query.knn.KNNQuery;
import de.lmu.ifi.dbs.elki.database.relation.Relation;
import de.lmu.ifi.dbs.elki.datasource.ArrayAdapterDatabaseConnection;
import de.lmu.ifi.dbs.elki.datasource.DatabaseConnection;
import de.lmu.ifi.dbs.elki.distance.distancefunction.geo.LatLngDistanceFunction;
import de.lmu.ifi.dbs.elki.index.tree.spatial.kd.SmallMemoryKDTree;
import de.lmu.ifi.dbs.elki.logging.LoggingConfiguration;
import de.lmu.ifi.dbs.elki.math.geodesy.WGS84SpheroidEarthModel;

public class kdTree_NestedJoin {

	public static void main(String[] args) throws IOException {
		// Set the logging level to statistics:
		LoggingConfiguration.setStatistics();
		int KNN_Size = 7;
		// Note: ELKI has a nice data generator class, use that instead.

		double[][] real_data = new double[10][3];
		int line = 0;
		// BufferedReader是可以按行读取文件
		FileInputStream inputStream = new FileInputStream("C:\\Users\\user\\Desktop\\Hash_Triple2HashValues_100_2PI.txt");
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
		HashMap<Integer, double[][]> hp = new HashMap<Integer, double[][]>();
		String str = null;
		while ((str = bufferedReader.readLine()) != null) {

			str = str.substring(1, str.length() - 1);

			if (line == 0) {
				String[] centroids = str.split(" , ");
				// System.out.println(str.split(" , ")[9]);
				for (int j = 0; j < centroids.length; j++) {
					str = centroids[j];
					real_data[j][0] = Double.valueOf(str.substring(1, str.length() - 1).split(",")[0]);
					real_data[j][1] = Double.valueOf(str.substring(1, str.length() - 1).split(",")[1]);
					real_data[j][2] = Double.valueOf(str.substring(1, str.length() - 1).split(",")[2]);

				}
				// System.out.println(real_data[9][0]+","+real_data[9][1]+","+real_data[9][2]);
			} else {
				String[] con = str.split(" , ");
				int leng = con.length;
				double[][] data = new double[leng][3];
				for (int i = 0; i < leng; i++) {
					str = con[i];
					data[i][0] = Double.valueOf(str.substring(1, str.length() - 1).split(",")[0]);
					data[i][1] = Double.valueOf(str.substring(1, str.length() - 1).split(",")[1]);
					data[i][2] = Double.valueOf(str.substring(1, str.length() - 1).split(",")[2]);
				}
				// System.out.println(data[leng-1][0]+","+data[leng-1][1]+","+data[leng-1][2]);
				hp.put(line - 1, data);
				// System.out.println(hp.size());
			}
			line++;
		}

		inputStream.close();
		bufferedReader.close();
		// System.out.println(real_data[2][0]);
		// ArrayAdapterDatabaseConnection dbc = new
		// ArrayAdapterDatabaseConnection(data);
		// Adapter to load data from an existing array.
		DatabaseConnection dbc = new ArrayAdapterDatabaseConnection(real_data);

		// Since the R-tree has so many options, it is a bit easier to configure it
		// using the parameterization API, which handles defaults, instantiation,
		// and additional constraint checks.

		SmallMemoryKDTree.Factory<?> indexfactory = new ELKIBuilder<>(SmallMemoryKDTree.Factory.class).build();
//		de.lmu.ifi.dbs.elki.index.tree.spatial.kd.MinimalisticMemoryKDTree.Factory indexfactory = new ELKIBuilder<>( MinimalisticMemoryKDTree.Factory.class).build();
		// Create the database, and initialize it.
		Database db = new StaticArrayDatabase(dbc, Arrays.asList(indexfactory));
		// This will build the index of the database.
		db.initialize();
		// Relation containing the number vectors we put in above:
		Relation<NumberVector> rel = db.getRelation(TypeUtil.NUMBER_VECTOR_FIELD);
		// We can use this to identify rows of the input data below.
		DBIDRange ids = (DBIDRange) rel.getDBIDs();

		// We use the WGS84 earth model, and "latitude, longitude" coordinates:
		// This distance function returns meters.
		LatLngDistanceFunction df = new LatLngDistanceFunction(WGS84SpheroidEarthModel.STATIC);

		// Let's find the closest points to target point:

		double[] t1 = new double[2];
		t1[0] = 2120941248;
		t1[1] = 201934756;
//		t1[2] = 0;
		double[] t2 = new double[3];
		// t2[0] = 2127393846;
		t2[1] = 528487333;

		// k nearest neighbor query:
		KNNQuery<NumberVector> RangeQuery_one = QueryUtil.getKNNQuery(rel, df, t1);
		KNNQuery<NumberVector> RangeQuery_two = QueryUtil.getKNNQuery(rel, df, t2);

		System.out.println("JOIN ALGORITHM");
		System.out.println("---------star-----" + System.currentTimeMillis());
		DoubleVector target1 = new DoubleVector(t1);
		DoubleVector target2 = new DoubleVector(t2);
		DoubleDBIDList RangeQuery_O_Results = RangeQuery_one.getKNNForObject(target1, 2);
		DoubleDBIDList RangeQuery_T_Results = RangeQuery_two.getKNNForObject(target2, 2);
		System.out.println(RangeQuery_O_Results.size());
		System.out.println(RangeQuery_T_Results.size());
		// Iterate over all results.
		ArrayList<Double> al = new ArrayList<Double>();
		for (DoubleDBIDListIter itO = RangeQuery_O_Results.iter(); itO.valid(); itO.advance()) {
			for (double value[] : hp.get(ids.getOffset(itO))) {
				double[] t3 = new double[2];
				t3[0] = value[0];
				t3[1] = value[1];
				al.add(EuclideanMetric.sim_distance(t3, t1));
				if (EuclideanMetric.sim_distance(t3, t1) <= 443.0) {
					System.out.println(value[0] + "," + value[1] + "," + value[2]);
				}
			}
		}
		Collections.sort(al);
		System.out.println(al.get(6));
		System.out.println("---------end------" + System.currentTimeMillis());
	}
}